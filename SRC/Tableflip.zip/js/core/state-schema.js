'use strict';

var STATE_VERSION = 1;

var RECOGNIZABLE_KEYS = ['base', 'baseCols', 'stacks', 'lookups', 'calcStages', 'filters', 'sorts', 'colOrder', 'selCols', 'aggMode', 'aggregates', 'colTotals', 'subtotalBy', 'subtotalFns', 'subtotalStrategy'];

function isRecognizableConfig(payload) {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return false;
  let matches = 0;
  for (const key of RECOGNIZABLE_KEYS) {
    if (key in payload) matches++;
  }
  return matches >= 2;
}
